package com.lef.orestis.bandwidthcalculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;

public class MainActivity extends AppCompatActivity {

    public RadioButton RadioButtonBytes, RadioButtonKiloBytes, RadioButtonMegaBytes, RadioButtonGigaBytes;
    public RadioButton RadioButtonBytesPs, RadioButtonKiloBytesPs, RadioButtonMegaBytesPs, RadioButtonGigaBytesPs;
    public TextView TimeResult, TimeResultText;
    public double FileSizeFormat;
    public double BandwidthFormat;
    public EditText FileSizeInput, BandwidthInput;
    public Button calc;

    public double years = 0, days = 0, hours = 0, minutes = 0, seconds = 0;

    public final double max_duble = 999999999999999999L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initialization();

        radioButtonOnCreateState();

        calc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                valeNumera();
            }
        });
    }

    public void radioButtonOnCreateState() {
        RadioButtonBytes.setChecked(true);
        FileSizeFormat = 8;
        RadioButtonBytesPs.setChecked(true);
        BandwidthFormat = 1;
    }

    public void valeNumera() {
        if (checkEmptyFields(FileSizeInput, BandwidthInput)) {
            int Filesize = Integer.parseInt(FileSizeInput.getText().toString());
            Long Bandwidth = Long.parseLong(BandwidthInput.getText().toString());
            setTime(Filesize, Bandwidth, FileSizeFormat, BandwidthFormat);
        }
    }

    public void initialization() {
        RadioButtonBytes = findViewById(R.id.byteRadioButton);
        RadioButtonKiloBytes = findViewById(R.id.kilobyteRadioButton);
        RadioButtonMegaBytes = findViewById(R.id.megabyteRadioButton);
        RadioButtonGigaBytes = findViewById(R.id.gigabyteRadioButton);

        RadioButtonBytesPs = findViewById(R.id.bytepsRadioButton);
        RadioButtonKiloBytesPs = findViewById(R.id.kilobytepsRadioButton);
        RadioButtonMegaBytesPs = findViewById(R.id.megabytepsRadioButton);
        RadioButtonGigaBytesPs = findViewById(R.id.gigabytepsRadioButton);

        FileSizeInput = findViewById(R.id.fileSizeEditText);
        BandwidthInput = findViewById(R.id.bandwidthEditText);

        TimeResultText = findViewById(R.id.timeText);
        TimeResult = findViewById(R.id.timeResult);

        calc = findViewById(R.id.calculateButton);
    }

    private boolean checkEmptyFields(EditText FileSizeInput, EditText BandwidthInput) {
        boolean empty = true;
        if (FileSizeInput.getText().toString().equals("")) {
            YoYo.with(Techniques.Shake).duration(700).repeat(2).playOn(FileSizeInput);
            empty = false;
        }
        if (BandwidthInput.getText().toString().equals("")) {
            YoYo.with(Techniques.Shake).duration(700).repeat(2).playOn(BandwidthInput);
            empty = false;
        }
        if (BandwidthInput.getText().toString().equals("0")) {
            empty = false;
            TimeResult.setText(R.string.max_time);
            YoYo.with(Techniques.Shake).duration(2000).repeat(3).playOn(TimeResultText);
            YoYo.with(Techniques.Tada).duration(2000).repeat(3).playOn(TimeResult);
        }
        return empty;
    }

    public void setTime(double mFileSize, double mBandwidth, double mFileSizeFormat, double mBandwidthFormat) {
        double timeInSeconds = (mFileSize * mFileSizeFormat)/(mBandwidth * mBandwidthFormat);
        if (timeInSeconds<1)
        {
            Log.d("timeInSeconds", "timeInSeconds "+String.valueOf(timeInSeconds));
            TimeResult.setText(R.string.min_time);
        }else{
            Log.d("timeInSeconds", "timeInSeconds "+String.valueOf(timeInSeconds));

            seconds = timeInSeconds % 60;
            minutes = timeInSeconds / 60 % 60;
            hours = timeInSeconds / 60 / 60 % 24;
            days = timeInSeconds / 60 / 60 / 24 % 365;
            years = timeInSeconds / 60 / 60 / 24 / 365;
            Log.d("timeInSeconds", "secnds : "+String.valueOf(seconds));
            Log.d("timeInSeconds", "minutes : "+String.valueOf(minutes));
            Log.d("timeInSeconds", "hours : "+String.valueOf(hours));
            Log.d("timeInSeconds", "days : "+String.valueOf(days));
            Log.d("timeInSeconds", "years : "+String.valueOf(years));
            showTime(years, days, hours, minutes, seconds);
        }
    }

    private void showTime(double years, double days, double houres, double minutes, double seconds) {
        String TimeResultText = null;
        if ((int)seconds>0|(int)minutes>0|(int)houres>0|(int)days>0|(int)years>0){
            TimeResultText = (int)seconds + " seconds";
            if ((int)minutes>0|(int)houres>0|(int)days>0|(int)years>0){
                TimeResultText = (int)minutes + " minutes, " + (int)seconds + " seconds";
                if ((int)houres>0|(int)days>0|(int)years>0){
                    TimeResultText = (int)houres + " hours, " + (int)minutes + " minutes, " + (int)seconds + " seconds";
                    if ((int)days>0|(int)years>0){
                        TimeResultText = (int)days + " days, " + (int)houres + " hours, " + (int)minutes + " minutes, " + (int)seconds + " seconds";
                        if ((int)years>0){
                            TimeResultText = (int)years+ " years, " + (int)days + " days, " + (int)houres + " hours, " + (int)minutes + " minutes, " + (int)seconds + " seconds";
                        }
                    }
                }
            }

        }
        TimeResult.setText(TimeResultText);
    }

    public void onRadioButtonClickedFS(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        switch (view.getId()) {
            case R.id.byteRadioButton:
                if (checked)
                    FileSizeFormat = 8;
                break;
            case R.id.kilobyteRadioButton:
                if (checked)
                    FileSizeFormat = 8192;
                break;
            case R.id.megabyteRadioButton:
                if (checked)
                    FileSizeFormat = 8388608;
                break;
            case R.id.gigabyteRadioButton:
                if (checked)
                    FileSizeFormat = 8589934592L;
                break;
        }
    }

    public void onRadioButtonClickedBW(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        switch (view.getId()) {
            case R.id.bytepsRadioButton:
                if (checked)
                    BandwidthFormat =  1;
                break;
            case R.id.kilobytepsRadioButton:
                if (checked)
                    BandwidthFormat = 1000;
                break;
            case R.id.megabytepsRadioButton:
                if (checked)
                    BandwidthFormat = 1e+6;
                break;
            case R.id.gigabytepsRadioButton:
                if (checked)
                    BandwidthFormat = 1e+9;
                break;
        }
    }
}
